from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
     PetViewSet, BookingViewSet, UserViewSet, 
    InvoiceViewSet, ReviewViewSet, ServiceListingViewSet, 
    UserProfileViewSet, MessageViewSet,
    UserRegistrationView, CurrentUserView
)
from django.contrib import admin
from django.urls import path, include
from django.http import Http404

# Technical Fix: The "Ghost Admin" Configuration.
# We override the default admin login. If a user finds the /admin/ URL but 
# does not have the is_superuser flag explicitly set, the server throws a 
# 404 Not Found instead of showing a login screen. This prevents brute-force.
class SecureAdminSite(admin.AdminSite):
    def has_permission(self, request):
        if not request.user.is_superuser:
            raise Http404("Page not found")
        return super().has_permission(request)

custom_admin_site = SecureAdminSite(name='custom_admin')

urlpatterns = [
    path('admin/', custom_admin_site.urls),
    path('api/', include('api.urls')),
]


router = DefaultRouter()
router.register(r'profiles', UserProfileViewSet, basename='profile')
router.register(r'pets', PetViewSet, basename='pet')
router.register(r'bookings', BookingViewSet, basename='booking')
router.register(r'providers', UserViewSet, basename='provider')
router.register(r'invoices', InvoiceViewSet, basename='invoice')
router.register(r'reviews', ReviewViewSet, basename='review')
router.register(r'services', ServiceListingViewSet, basename='service')
router.register(r'messages', MessageViewSet, basename='message')

urlpatterns = [
    path('', include(router.urls)),
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('auth/me/', CurrentUserView.as_view(), name='auth_me'),
]